const db = require('./db');
const helper = require('../helper');
const config = require('../config');

//Fungsi get all data
async function getMultiple(page = 1){
  const offset = helper.getOffset(page, config.listPerPage);
  const rows = await db.query(
    `SELECT id, name, started_year, divisi, age
    FROM jagoan_api LIMIT ${offset},${config.listPerPage}`
  );
  const data = helper.emptyOrRows(rows);
  const meta = {page};

  return {
    data,
    meta
  }
}

//Fungsi post data
async function create(jagoan){
  const result = await db.query(
    `INSERT INTO jagoan_api 
    (name, started_year, divisi, age) 
    VALUES 
    ('${jagoan.name}', ${jagoan.started_year}, '${jagoan.divisi}', ${jagoan.age})`
  );

  let message = 'Error in creating data';

  if (result.affectedRows) {
    message = 'Data created successfully';
  }

  return {message};
}

//update data
async function update(id, jagoan){
  const result = await db.query(
    `UPDATE jagoan_api
    SET name="${jagoan.name}", started_year=${jagoan.started_year}, divisi="${jagoan.divisi}", 
    age=${jagoan.age} 
    WHERE id=${id}` 
  );

  let message = 'Error in updating data';

  if (result.affectedRows) {
    message = 'Data updated successfully';
  }

  return {message};
}

//remove data
async function remove(id){
  const result = await db.query(
    `DELETE FROM jagoan_api WHERE id=${id}`
  );

  let message = 'Error in deleting Data';

  if (result.affectedRows) {
    message = 'Data deleted successfully';
  }

  return {message};
}

//handling
module.exports = {
  getMultiple,
  create,
  update,
  remove
}
